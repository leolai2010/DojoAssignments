$('.back-select').hover(function(){
    var img = $(this).data('img');
    console.log(img)
    $('.wrapper').css('background', 'url(' + img + ')');
    $('.wrapper').css('background-size', 'cover');
}, function(){
    $('.wrapper').css('background', 'black');
})

$('.back-select').click(function(){

    $(this).off('mouseenter mouseleave');
    $('.background-box').hide();
    $('.ninja-box').show();
    
    var img = $(this).data('img');
    $('.wrapper').css('background', 'url(' + img + ')');
    $('.wrapper').css('background-size', 'cover');

});

$('.ninja-choice').change(function(){
    var side = $(this).attr('id');
    var img = $(this).val();
    console.log(img);
    console.log(side);
    if(side == 'ninjaOne'){
        var html_str = '<img src="'
        html_str += img
        html_str += '" alt="">'
        console.log(html_str)
        $('#left').html(html_str);
    }else{
        var html_str = '<img src="'
        html_str += img
        html_str += '" alt="">'
        console.log(html_str)
        $('#right').html(html_str);
    }
})

