$(document).ready(function(){
    for(i = 1; i <=151; i ++){  
       $("#pokemondisplayer").append("<img src='http://pokeapi.co/media/img/" + i + ".png'>");   
}    
})