// Write a function that is given a number and a digit. Return that numeric value of that digit 
// Example: Given 5411 and 2 --> return 4
// Given 98776 and 4 --> return 7

function digitExtractor(num, idx){
    num += "";
    return num[idx - 1];
}

var result = digitExtractor(9876, 2);
console.log(result);