// Write two functions. The first function will have two parameters
// your function will add those two parameters together and return the sum

// The second function will take the return value of the first function square and return that value

function add(numOne, numTwo){
    return numOne + numTwo;
}

function square(num){
    return num * num; 
}

var sum = add(5,6);
var result = square(sum);
console.log(result);