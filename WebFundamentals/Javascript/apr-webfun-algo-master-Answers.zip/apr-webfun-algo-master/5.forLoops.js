// Create a for loop that prints "I can code!" 50 times. 
for(var i = 0; i < 50; i++){
    console.log('I can code!');
}

for(var i = 99; i > 0; i--){
    console.log(i + " Bottles");
}
// Create a for loop that prints "99 bottles" and then counts all the down to 0
// example -- 
// 99 Bottles
// 98 Bottles
// 97 Bottles
// 96 Bottles 
// etc.
