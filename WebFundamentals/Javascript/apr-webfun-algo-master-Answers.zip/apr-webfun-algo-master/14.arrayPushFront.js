// Write a function that takes in an array and a value
// You should add the value into index 0 (the front of the array) while maintaing the order of the rest of the array 

function pushFront(arr, val){
    arr.push(val);
    for(var i = arr.length -1; i > 0; i--){
        arr[i] = arr[i-1];
    }
    arr[0] = val;
    return arr;
}

console.log(pushFront([1,2,3,4], 90))