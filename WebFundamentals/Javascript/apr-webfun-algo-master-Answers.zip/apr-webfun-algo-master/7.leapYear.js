// Write a function that takes in a year and returns whether it's a leap year. 
// Determining a leap year is as follows 
// If a year is divisible by 4 it is a leap year unless it's divisible by 100. However, if it's divisible by 400 it is a leap year 


function isLeapYear(year){
    if(year % 4 == 0){
        if(year % 100 == 0){
            if(year % 400 == 0){
                return true;
            }
            return false;
        }
        return true;
    }
    return false;
}

console.log(isLeapYear(16));
console.log(isLeapYear(100));
console.log(isLeapYear(400));