// What will the following print out? Run the code to test your answer. 

// 1.
var myStr = 'name';
if('name' === myStr){
    console.log('Coding!')
}

// Your Answer

// 2.
if('1' === 1){
    console.log('One');
}else{
    console.log(1);
}

// Your Answer

// 3. 
var awesome = 0;
if(awesome){
    console.log('You are awesome');
}

// Your Answer


// 4. 
var myVar = 100;
if(myVar){
    console.log("100%");
}

// 5.
var testArr = [1,'LBJ', 2, 'MJ']
if(testArr){
    console.log('GOAT');
}