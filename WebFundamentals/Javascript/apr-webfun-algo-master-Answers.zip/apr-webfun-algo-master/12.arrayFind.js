// Write a function that takes in an array and a value. 
// Return true if the value is in the array, return false if the value is not in the array


function arrayFind(arr, val){
    for(var i = 0; i < arr.length; i++){
        if(arr[i]==val){
            return true;
        }
    }
    return false;
}

// Example call
var result = arrayFind([1,2,3,4,5,90], 80)
var positive = arrayFind([1,2,3,4,5,90], 5)
console.log(result);
console.log(positive)