// We're going to create a game. Here are the rules.

// 1. Create a rollOne function that returns a random number between 1 and 6
// 2. Create a playFives(num) function that will call rollOne num number of times.
    // Each time rollOne is called print the value it returns 
    // If the returned value is 5 also print "Good Luck"

// 3. Create a third function called playStatistics
    // This should call rollOne eight times 
    // At the end of the eight times it should print out the highest and lowest numbers that were rolled

// 4. Create a fourth function called statisticsTwo
    // This should also call rollOne eight times 
    // Print the sum of all 8 rolls 

// 5. Create a fifth funciton called statisticsThree 
    // This should call rolleOne eight time
    // Print the average of the eight rolls