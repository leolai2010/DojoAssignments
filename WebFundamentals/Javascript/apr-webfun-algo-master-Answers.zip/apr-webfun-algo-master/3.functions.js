// Create three functions named one, two, and three. Have each function print something different. Invoke each function

function one(){
    console.log('Test function one');
}
function two(){
    console.log('Test function two');
}
function three(){
    console.log('Test function three');
}

one();
two();
three();