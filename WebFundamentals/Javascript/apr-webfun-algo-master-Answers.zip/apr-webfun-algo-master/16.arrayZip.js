// Write a function that takes in two arrays.
// Create a new array that zips the two arrays together
// Example: Given [1,2,3] and [10,20,40,50] you should return [1,10,2,20,3,40,50]


function arrayZip(arrayOne, arrayTwo){
    var newArr = [];
    // if (arrayOne.length > arrayTwo.length){
    //     var longest = arrayOne;
    //     var shortest = arrayTwo;
    // }else{
    //     var longest = arrayTwo;
    //     var shortest = arrayOne;
    // }
    // for(var i = 0; i < longest.length; i++){
    //     if(shortest[i]){
    //         newArr.push(shortest[i], longest[i]);
    //     }else{
    //         newArr.push(longest[i]);
    //     }
    // }
    var i = 0;
    var j = 0;

    while(i < arrayOne.length && j < arrayTwo.length){
        newArr.push(arrayOne[i])
        newArr.push(arrayTwo[j])
        i++;
        j++
    }
    while(i < arrayOne.length){
        newArr.push(arrayOne[i])
        i++;
    }
    while(j < arrayTwo.length){
        newArr.push(arrayTwo[j]);
        j++
    }
    return newArr;
}

var one = [1,2,3]
var two = [10,20,40,50]

var result = arrayZip(one, two);
console.log(result);