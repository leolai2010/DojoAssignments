// Write a function that takes in an array, a value, and an index.
// Insert the value into the array at the given index
// example given [1,2,3], 5, 1 you would return [1,5,2,3]


function insertAt(arr, val, idx){
    if(idx > arr.length-1){
        arr[idx] = val;
        return arr;
    }
    arr.push(val);
    console.log(arr);
    for(var i = arr.length-1; i > idx; i--){
        var temp = arr[i];
        arr[i] = arr[i-1];
        arr[i-1] = temp;
        console.log("Index is " + i + " Array is " + arr);
    }
    return arr;
}

var arr = [1,2,3,7,8,9]
var result = insertAt(arr, 5, 7);
console.log(result);