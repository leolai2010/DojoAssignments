// Write a function that takes in an array and prints out all the values in the array 

function printVals(arr){
// Your code here
    for(var i = 0; i < arr.length; i++){
        console.log(arr[i]);
    }
}

printVals([4,5,6,8])