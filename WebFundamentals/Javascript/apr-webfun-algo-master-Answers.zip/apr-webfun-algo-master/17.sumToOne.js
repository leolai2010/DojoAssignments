// Write a function that given a number sums up the values until there is a single digit left
// Example: given 678 I would at 6 + 7 + 8 = 21. Since 21 is not a single digit I will add again 
// 21 ==> 2 + 1 = 3. Since 3 is a single digit I will return 3

function sumToOne(num){
    num += "";
    while(num.length > 1){
        var sum = 0;
        console.log("Before for loop the num is " + num);
        for(var i = 0; i < num.length; i++){
            // var el = parseInt(num[i]);
            // sum += el;
            sum += parseInt(num[i]);
        }
        num = sum + "";
    }
    return parseInt(num);
}

var result = sumToOne(9007199254740991);
// 9,007,199,254,740,991
console.log(result);


function shortSum(num){
    return num % 9 || 9;
}
var test = shortSum(9007199254740991);
console.log(test);