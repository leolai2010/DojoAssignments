// Write a function that returns the number of positive values in the array

function countPositive(arr){
    var count = 0;
    for(var i = 0; i < arr.length; i++){
        if(arr[i] > 0){
            count++;
        }
    }
    return count;
}

console.log(countPositive([3,4,-5,6,-9]))


var str = "<img src='https://pokeapi.co/media/img/" + i + ".png'>"