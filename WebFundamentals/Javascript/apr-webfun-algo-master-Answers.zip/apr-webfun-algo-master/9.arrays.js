// Create an array with 5 values
var arr = [1,2,3,4,5]
// Print the last value of the array
console.log(arr[arr.length-1])
// Push two new values in 
arr.push(10);
arr.push(20);
// Print out the length of the array 
console.log(arr.length);
// Print out the last value in the array
console.log(arr[arr.length-1]);
// Print out the second value of the array
console.log(arr[1])