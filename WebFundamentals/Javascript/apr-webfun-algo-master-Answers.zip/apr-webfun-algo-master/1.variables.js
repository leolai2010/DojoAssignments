// Create 5 variables. Each should hold a different data type. Print each variable

