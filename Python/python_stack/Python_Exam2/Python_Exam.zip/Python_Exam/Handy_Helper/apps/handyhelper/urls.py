from django.conf.urls import url
from . import views           
urlpatterns = [
    url(r'^$', views.index),  
    url(r'^registration$', views.registration),
    url(r'^login$', views.login),
    url(r'^logout$', views.logout),
    url(r'^dashboard$', views.dashboard),
    url(r'^addJob$', views.addJob),
    url(r'^addfunction$', views.addfunction),
    url(r'^edit/(?P<number>\d+)$', views.edit),
    url(r'^editfunction$', views.editfunction),
    url(r'^destroy/(?P<number>\d+)$', views.destroy),
    url(r'^show/(?P<number>\d+)$', views.show),
    url(r'^add_favorite/(?P<number>\d+)$', views.add_favorite),
    url(r'^remove_favorite/(?P<number>\d+)$', views.remove_favorite),
]