from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from .models import *
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
import bcrypt

def index(request):
    return render(request, 'index.html')
def current_user(request):
	return User.objects.get(id = request.session['user_id'])
def registration(request):
    if request.method == "POST":
        result = User.objects.valdiate_info(request.POST)
        if 'errors' in result:
            for key,value in result['errors'].items():
                messages.error(request, value)
        else:
            messages.success(request, 'Registration Successful! Welcome!')
        return redirect('/')
    return redirect('/')
def login(request):
    if request.method == "POST":
        users_with_email = User.objects.filter(email = request.POST['user_email'])
        if len(users_with_email) > 0:
            print('user with the email exists! checking passswords now....')
            the_user = users_with_email.first()
            if bcrypt.checkpw(request.POST['password'].encode('utf-8'), the_user.password.encode('utf-8')):
                print('the passwords match! adding to session')
                request.session['user_id'] = the_user.id
                request.session['user_name'] = the_user.first_name
                # messages.success(request, 'yuo have logged in, {}!'.format(request.session['user_name']))
                return redirect('/dashboard')
            else:
                print('passwords do not match')
                messages.error(request, "invalid info")
                return redirect('/')
        else:
            messages.error(request, "invalid info, no users with that email")
            return redirect('/')
def logout(request):
    request.session.clear()
    return redirect('/')
def dashboard(request):
    user = current_user(request)
    context = {
        'user_info': User.objects.all(),
        'job_info': Job.objects.exclude(favorited_users = user),
        'favorites': user.favorited_jobs.all(),
        'user_name': user
        }
    return render(request, 'dashboard.html', context)
def addJob(request):
    return render(request, 'addJob.html')
def addfunction(request):
    if request.method == 'POST':
        errorms = Job.objects.validate_info(request.POST)
        if 'errors' in errorms:
            for key,value in errorms['errors'].items():
                messages.error(request,value)
            return redirect('/addJob')
        else:
            messages.success(request, "Job has been successfully added!")
            return redirect('/dashboard')
def edit(request, number):
    job = Job.objects.get(id=number)
    context = { 'job_info':job }
    return render(request, 'edit.html', context)
def editfunction(request):
    if request.method == 'POST':
        errorms = Job.objects.validate_edit(request.POST)
        if 'errors' in errorms:
            for key,value in errorms['errors'].items():
                messages.error(request,value)
            return redirect(request.META['HTTP_REFERER'])
        else:
            messages.success(request, "Job has been successfully updated!")
            return redirect('/dashboard')
def add_favorite(request, number):
	user = current_user(request)
	favorite = Job.objects.get(id=number)
	user.favorited_jobs.add(favorite)
	return redirect('/dashboard')
def remove_favorite(request, number):
	user = current_user(request)
	favorite = Job.objects.get(id=number)
	user.favorited_jobs.remove(favorite)
	return redirect('/dashboard')
def show(request, number):
    job = Job.objects.get(id=number)
    context = { 'job_info': job }
    return render(request, 'show.html', context)
def destroy(request, number):
    deleter = Job.objects.get(id=number)
    deleter.delete()
    return redirect('/dashboard')
def users(request,number):
    user = User.objects.get(id=number)
    context = { 
        'user_info':user,
        'favorites':user.favorited_jobs.all()
        }
    return render(request, 'users.html', context)