from django.apps import AppConfig


class RegnlogConfig(AppConfig):
    name = 'RegnLog'
