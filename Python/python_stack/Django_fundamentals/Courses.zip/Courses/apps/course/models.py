from django.db import models
class CourseManager(models.Manager):
    def validate_info(self, postData):
        errors = {}
        if len(postData['course_name']) == 0:
            errors['course_name'] = 'Course Name cannot be Empty!'
        if len(postData['course_name']) < 5:
            errors['course_name'] = 'Course Name is too Short! Need to be Five Characters or More!'
        if len(postData['description_txt']) == 0:
            errors['description_txt'] = 'Description cannot be Empty!'
        if len(postData['description_txt']) < 15:
            errors['description_txt'] = 'Description is too Short! Need to be Fifteen Characters or More!'
        if len(errors):
            result = {
                'errors':errors
            }
            return result
        else:
            info = self.create(name = postData['course_name'], desc = postData['description_txt'])
            result = {
                'infos':info
            }
            return result
class Course(models.Model):
    name=models.CharField(max_length=255)
    desc=models.TextField()
    created_at= models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = CourseManager()