from django.apps import AppConfig


class RandomWordGeneratorConfig(AppConfig):
    name = 'Random_Word_Generator'
