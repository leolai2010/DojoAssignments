public class FizzBuzzTest {
    public static void main(String[] args) {
        FizzBuzz iD = new FizzBuzz();
        String FiBu = iD.fizzBuzz(5);
        System.out.println(FiBu);
    }
}