public class PythagoreanTest {
    public static void main(String[] args) {
        Pythagorean iD = new Pythagorean();
        Double calH = iD.calculateHypotenuse(5 , 7);
        System.out.println(calH);
    }
}