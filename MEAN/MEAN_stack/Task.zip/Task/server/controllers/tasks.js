const mongoose = require('mongoose');
var Task = mongoose.model('Task');
module.exports = {
    index:(req,res)=>{
        Task.find({}, (err,task)=>{
            if(err){
                console.log("Returned error", err);
                res.json({message: "Error", error: err});
             }
             else {
                res.json({data: task});
             }
        });
    },
    new:(req,res)=>{
        var task = new Task(req.body)
        task.save((err,task)=>{
            if(err){
                console.log("Returned error", err);
                res.json({message: "Error", error: err});
            } else {
                res.json({data: task});
            }
        });
    },
    delete:(req,res)=>{
        Task.remove({_id:req.params.id}, (err,task)=>{
            if(err){
                console.log("Returned error", err);
                res.json({message: "Error", error: err});
            } else {
                res.json({data: task});
            }
        });
    },
    show:(req,res)=>{
        Task.find({task:req.params.name}, (err,task)=>{
            if(err){
                console.log("Returned error", err);
                res.json({message: "Error", error: err});
            } else {
                res.json({data: task});
            }
        })
    }
}