import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  constructor(private _http: HttpClient) {
  }
  getMovies() {
    return this._http.get('/movies');
  }
  getShowMovie(id){
    return this._http.get('/show/movie/'+ id);
  }
  postNewMovie(newmovie){
    return this._http.post('/new/movie/', newmovie);
  }
  getComment() {
    return this._http.get('/rate/comment/');
  }
  getShowComment(id){
    return this._http.get('/show/comment/'+ id);
  }
  postNewComment(id ,newcomment){
    return this._http.post('/new/comment/'+ id, newcomment);
  }
  deleteMovie(id){
    return this._http.get('/delete/movie/'+id);
  }
  deleteComment(name){
    return this._http.get('/delete/comment/'+name);
  }
}
