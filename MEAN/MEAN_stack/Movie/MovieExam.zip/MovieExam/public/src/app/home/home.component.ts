import { Component, OnInit, Input } from '@angular/core';
import { HttpService } from '../http.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  @Input()
  movies:any;
  edit:any;
  constructor(private _httpService: HttpService, private _router: Router, private_route: ActivatedRoute) { 
  }
  ngOnInit() {
    this.getAllMovie();
  }
  getAllMovie(){
    let observable = this._httpService.getMovies();
    observable.subscribe(data=>{
      this.movies = data;
    })
  }
  editClick(id): void{
    let observable = this._httpService.getShowMovie(id);
    observable.subscribe(data =>{
      this.edit = data;
      console.log(this.edit);
      this._router.navigate(['edit/'+id]);
    });
  }

}
