import { Component, OnInit, Input } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Router,  Params } from '@angular/router';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})
export class MovieComponent implements OnInit {
  @Input()
  movie:any;
  delete:any;
  content:any;
  name:any;
  rating:any;
  comment:any;
  constructor(private _httpService: HttpService, private _route: ActivatedRoute, private _router: Router) { }

  ngOnInit() {
    this._route.params.subscribe((params: Params)=>{
      this._httpService.getShowMovie(params["id"]).subscribe(data=>{
        this.movie = data;
        this.name = this.movie.name;
        this.rating = this.movie.rating;
        this.comment = this.movie.comment;
        console.log(this.movie);
      })
    });
  }
  deleteEdit(id): void{
    let observable = this._httpService.deleteMovie(id);
    observable.subscribe(data =>{
      this.delete = data;
      this._router.navigate(['/movies']);
    })
  }
  deleteComment(name): void{
    let observable = this._httpService.deleteComment(name);
    observable.subscribe(data =>{
      this.delete = data;
    })
  }
}
