import { Component, OnInit, Input } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Router,  Params } from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  @Input()
  edit:any;
  newComment:any;
  constructor(private _httpService: HttpService, private _route: ActivatedRoute, private _router: Router) { }

  ngOnInit() {
    this._route.params.subscribe((params: Params)=>{
      this._httpService.getShowMovie(params["id"]).subscribe(data=>{
        this.edit =data;
      })
    });
    this.newComment = { name:"", rating:"", comment:"" }
  }
  onEditSubmit(id){
    let observable = this._httpService.postNewComment(id, this.newComment);
    observable.subscribe(data=>{
      this._router.navigate(['/home']);
      console.log(data);
    })
  }
}
